package lu.tudor.santec.dicom.gui.viewer;

public interface WindowListener {

    void setWindow(DicomImagePanel source, int windowCenter, int windowWidth);

}
