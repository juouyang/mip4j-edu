package lu.tudor.santec.dicom.gui;

import java.util.Vector;

public interface DicomFilter {

	public void setDicomFilterTags(Vector headerTags);
	
}
