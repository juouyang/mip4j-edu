package lu.tudor.santec.dicom.receiver;

public interface DICOMListener {
	public void fireDicomEvent(DicomEvent event) ;
}
