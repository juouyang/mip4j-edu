package lu.tudor.santec.dicom.gui.header;

public interface TagListener {

	public void tagChanged(HeaderTag tag);
	
}
